#task 1
length = int(input())
width = int(input())
area = length * width
perimeter = (2* (length*width))
print(f"The area of the rectangle is {area} and the perimeter is {perimeter}.")

#task 2
principal = float(input("Enter your principal amount"))
rate = float(input("Enter your rate amount"))
time = float(input("Enter your time"))
calculation = (principal*rate*time)/100
total_amount = calculation + principal
print(f"The simple interest is {calculation} and the total amount after {time} years will be {total_amount}.")


#task 3
score = int(input('Enter your score'))
if score >= 90 <= 100:
    grade = "A"
    print((f"The grade is {grade} and the analysis is Excellent."))
elif score >= 80 <= 90:
    grade = "B"
    print((f"The grade is {grade} and the analysis is Good."))
elif score >=70 <= 80:
    grade = 'C'
    print((f"The grade is {grade} and the analysis is Average."))
elif score >= 60<= 70:
    grade = "D"
    print((f"The grade is {grade} and the analysis is Below Average."))
else:
    grade = "F"
    print((f"The grade is {grade} and the analysis is Poor."))




